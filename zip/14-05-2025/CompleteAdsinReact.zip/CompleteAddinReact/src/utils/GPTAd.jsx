import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

const GPTAd = ({ adUnitPath, sizes, divId }) => {
  const adRef = useRef(null);
  const location = useLocation();

  useEffect(() => {
    window.googletag = window.googletag || { cmd: [] };
    const googletag = window.googletag;

    if (!document.querySelector('script[src*="googletagservices.com"]')) {
      const gptScript = document.createElement('script');
      gptScript.src = 'https://www.googletagservices.com/tag/js/gpt.js';
      gptScript.async = true;
      document.head.appendChild(gptScript);
    }

    const initializeAd = () => {
      const existingSlots = googletag.pubads().getSlots();
      const existingSlot = existingSlots.find(slot => slot.getSlotElementId() === divId);

      if (existingSlot) {
        googletag.destroySlots([existingSlot]);
      }

      const slot = googletag.defineSlot(adUnitPath, sizes, divId)?.addService(googletag.pubads());

      googletag.pubads().enableSingleRequest();
      googletag.enableServices();

      googletag.display(divId);
      googletag.pubads().refresh([slot]);
    };

    googletag.cmd.push(() => {
      if (adRef.current) {
        initializeAd();
      }
    });

    return () => {
      const slots = googletag.pubads().getSlots();
      const slot = slots.find(s => s.getSlotElementId() === divId);
      if (slot) {
        googletag.destroySlots([slot]);
      }
    };
  }, [location.pathname]); 

  return (
    <div
      id={divId}
      ref={adRef}
      style={{
        minWidth: Math.min(...sizes.map(size => size[0])) + 'px',
        minHeight: Math.min(...sizes.map(size => size[1])) + 'px',
        margin: '0 auto',
        textAlign: 'center'
      }}
    />
  );
};

export default GPTAd;
